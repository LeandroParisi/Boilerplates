import { gaEvent } from 'utils/ga'
import isPreRendering from 'utils/isPreRendering'
import * as providers from './provider'

export default setRoot => {
  const setError = error =>
    setRoot(prev => ({
      ...prev,
      error,
    }))

  const sendEmail = async (email, sendMailResale) => {
    setRoot(prev => ({
      ...prev,
      sendLeadEmailLoading: true,
    }))

    const [, err] = await providers.sendEmail(email, sendMailResale)

    if (err) {
      return setRoot(prev => ({
        ...prev,
        sendLeadEmailError: true,
        sendLeadEmailLoading: false,
      }))
    }
    if (!isPreRendering()) {
      gaEvent({
        category: 'L_rosie_alerta',
        action: 'submit',
      })
    }

    return setRoot(prev => ({
      ...prev,
      sendLeadEmailLoading: false,
    }))
  }

  const setCookies = cookies => {
    setRoot(prev => ({
      ...prev,
      cookies,
    }))
  }

  const setLeadModal = leadModalStatus => {
    setRoot(prev => ({
      ...prev,
      leadModal: leadModalStatus,
    }))
  }

  const setActiveTerm = term => {
    setRoot(prev => ({
      ...prev,
      activeTerm: term,
    }))
  }

  return { setError, sendEmail, setCookies, setLeadModal, setActiveTerm }
}
