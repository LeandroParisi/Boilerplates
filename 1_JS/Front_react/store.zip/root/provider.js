import { apiWithoutPropertySuffix } from 'lib/api'
import to from 'lib/to'

export const fetchHomeNumbers = () => to(apiWithoutPropertySuffix.get('/home'))

export const sendEmail = (email, send_mail_resale) =>
  to(
    apiWithoutPropertySuffix.post('/lead', {
      email,
      send_mail_resale,
    })
  )
