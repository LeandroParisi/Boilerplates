import { useState, useMemo } from 'react'
import useCreateStore from '../../lib/useCreateStore'
import rootActions from './actions'
import rootSelectors from './selectors'
import terms from '../../pages/Terms/dict'
// Store para armazenar os dados globais da aplicação

const showCookies = () => {
  const isCookiesAccepted = window.localStorage.getItem('cookiesResale')

  if (isCookiesAccepted) {
    return false
  }
  return true
}

const initialState = {
  error: null,
  sendLeadEmailLoading: false,
  sendLeadEmailError: false,
  leadModal: {
    openModal: !window.localStorage.getItem('emailResale'),
    wasOpened: false,
  },
  cookies: showCookies(),

  activeTerm: terms.TERMS_OF_USE,
}

const RootStore = useCreateStore(() => {
  const [$root, setRoot] = useState(initialState)
  const actions = useMemo(() => rootActions(setRoot), [])
  const selectors = rootSelectors($root)

  return { $root, ...actions, ...selectors }
})

export const useRoot = () => RootStore()
export const RootContext = RootStore.Context
export const RootProvider = RootStore.Provider
