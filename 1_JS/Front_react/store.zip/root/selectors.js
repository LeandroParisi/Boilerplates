import { fetchHomeNumbers } from './provider'

export default ($root = {}) => {
  const getError = () => $root.error

  const getHomeNumbers = async () => {
    const [data, err] = await fetchHomeNumbers()

    if (err || !data) {
      console.log('Erro ao buscar os numeros da Home')
      return null
    }

    return data.data
  }

  const getSendLeadEmail = () => {
    const { sendLeadEmailLoading, sendLeadEmailError } = $root

    return {
      sendLeadEmailLoading,
      sendLeadEmailError,
    }
  }

  return { getHomeNumbers, getSendLeadEmail, getError }
}
